using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AiCorpseCheck : MonoBehaviour
{
    public bool corpseWasChecked = false;

}
